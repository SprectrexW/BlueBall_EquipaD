Projeto BlueBall.

>> Equipa Responsável:
D

>> Membros:
Ricardo Veiga
ID: TitanPrime

Erick Vaca
ID: Titan11


>> Links Utéis:

	> Apresentação:
	https://www.canva.com/design/DAFFHOHsWC8/9LWLz8GOzp8gRO5zRbMPRQ/view?utm_content=DAFFHOHsWC8&utm_campaign=designshare&utm_medium=link&utm_source=publishsharelink
	

	> Repositório Git:
	https://github.com/SprectrexW/BlueBall_EquipaD.git


	> Acompanhamento do Projeto, Link Jira:
	https://spectrexweb.atlassian.net/jira/software/c/projects/BLUEB/boards/2?atlOrigin=eyJpIjoiODVkNDEwYTJkNDM3NGQ2OTg3ZWVhMDQwZDI5Y2Q1ZDciLCJwIjoiaiJ9




